const axios = require("axios");

module.exports.config = {
    name: "apikey",
    version: "1.0.0",
    hasPermssion: 1,
    credits: "Pcoder",
    description: "Đăng ký API Key",
    commandCategory: "Tiện ích",
    usages: "~register-api <name>",
    cooldowns: 5,
    dependencies: {}
}

module.exports.run = async function({ api, event, args }) {
    const { threadID, messageID } = event;

    if (args.length === 0) {
        api.sendMessage("Vui lòng cung cấp tên của bạn để đăng ký API key. Sử dụng lệnh ~register-api <name>", threadID, messageID);
        return;
    }

    const name = args.join(" "); // Lấy tên từ đối số

    try {
        // Gửi yêu cầu đăng ký API key
        const url = `https://regular-mastiff-cheerful.ngrok-free.app/apikey?type=register&name=${name}`;
        const response = await axios.get(url);

        // Kiểm tra phản hồi từ API
        if (response.status === 200 && response.data.apiKey) {
            const apiKey = response.data.apiKey;
            api.sendMessage(`API Key của bạn là: ${apiKey}`, threadID, messageID);
        } else {
            api.sendMessage("Lỗi khi đăng ký API Key. Vui lòng thử lại.", threadID, messageID);
        }
    } catch (error) {
        console.error(error);
        api.sendMessage("Lỗi khi kết nối tới API. Vui lòng thử lại.", threadID, messageID);
    }
}
