const fs = require('fs').promises;
const path = require('path');

module.exports.config = {
    name: "rs",
    version: "1.0.0",
    hasPermssion: 0,
    credits: "Bot Developer",
    description: "Restart lại các module trong thư mục 'modules/command' và 'modules/events' khi có thay đổi, giữ nguyên code chưa thay đổi.",
    commandCategory: "System",
    usages: "restartChangedModules",
    cooldowns: 5
};

module.exports.run = async function({ api, event }) {
    try {
        // Đảm bảo rằng đường dẫn đúng bằng cách sử dụng path.resolve() để tạo đường dẫn tuyệt đối từ thư mục gốc
        const commandFolder = path.resolve(__dirname, 'modules/command');
        const eventsFolder = path.resolve(__dirname, 'modules/events');

        // Lưu trữ thời gian thay đổi của các tệp
        const fileModifiedTimes = {};

        // Hàm để xử lý việc restart các module trong thư mục
        const restartModulesInFolder = async (folderPath) => {
            try {
                const files = await fs.readdir(folderPath); // Lấy danh sách các file trong thư mục

                // Lọc ra các file JS trong thư mục
                const jsFiles = files.filter(file => file.endsWith('.js'));

                for (const file of jsFiles) {
                    const filePath = path.join(folderPath, file);
                    const stat = await fs.stat(filePath);

                    // Nếu tệp chưa được lưu thời gian thay đổi hoặc tệp bị thay đổi, reload lại
                    if (!fileModifiedTimes[filePath] || fileModifiedTimes[filePath] !== stat.mtimeMs) {
                        console.log(`Reloading module: ${file}`);
                        delete require.cache[require.resolve(filePath)];
                        require(filePath);
                        fileModifiedTimes[filePath] = stat.mtimeMs; // Cập nhật thời gian sửa đổi của tệp
                    }
                }
            } catch (err) {
                throw new Error('Không thể đọc thư mục: ' + err);
            }
        };

        // Kiểm tra và restart các module trong cả hai thư mục 'command' và 'events'
        await restartModulesInFolder(commandFolder);
        await restartModulesInFolder(eventsFolder);

        // Gửi thông báo cho người dùng
        api.sendMessage('Đã restart lại các module có thay đổi trong thư mục "modules/command" và "modules/events".', event.threadID, event.messageID);

    } catch (e) {
        console.log("Lỗi khi thực hiện restart:", e);
        api.sendMessage('Đã xảy ra lỗi khi restart lại các module.', event.threadID, event.messageID);
    }
};
