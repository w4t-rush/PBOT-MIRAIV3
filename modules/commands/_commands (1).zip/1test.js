module.exports.config = {
    name: "autoChao",
    version: "1.1.0",
    hasPermssion: 0,
    credits: "GPT",
    description: "Bot tự động chào khi có ai đó được tag và chào",
    commandCategory: "Tiện ích",
    usages: "Tag ai đó và chào",
    cooldowns: 5
};

module.exports.handleEvent = async ({ event, api, Users }) => {
    const { threadID, messageID, senderID, mentions, body } = event;
    
    // Kiểm tra nếu tin nhắn có tag ai đó
    if (Object.keys(mentions).length === 0) return;

    // Danh sách từ khóa kích hoạt chào
    const greetings = ["chào", "hi", "hello", "hí", "hú", "helo", "xin chào", "hiii", "helu"];

    // Kiểm tra nếu tin nhắn chứa bất kỳ từ khóa nào trong danh sách
    const messageText = body.toLowerCase();
    const hasGreeting = greetings.some(greeting => messageText.includes(greeting));

    if (!hasGreeting) return;

    // Lấy danh sách những người được tag và tạo nội dung tin nhắn chào lại
    const mentionIDs = Object.keys(mentions);
    const senderName = await Users.getNameUser(senderID);
    let message = `Chào `;
    let mentionList = [];
    let index = 5; // Bắt đầu vị trí index để tag

    mentionIDs.forEach((id, idx) => {
        const name = mentions[id];
        message += `${name}${idx < mentionIDs.length - 1 ? ", " : ""} `;
        mentionList.push({
            tag: `@${name}`,
            id: id,
            fromIndex: index
        });
        index += name.length + 2;
    });

    message += `, bạn ${senderName} vừa chào bạn kìa! 😊`;

    // Gửi tin nhắn chào lại và tag đúng người
    return api.sendMessage({ body: message, mentions: mentionList }, threadID, messageID);
};

module.exports.run = () => {
    // Hàm này để giữ nguyên, bot không cần chạy gì khi gọi lệnh
};
